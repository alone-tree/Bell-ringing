# coding:utf-8

from playsound import playsound
import os
import time

def task_1():
    file = './music/ClassBell.mp3'
    try:
        playsound(file)
        play_log("上课", "succees", file)
    except:
        play_log("上课", "fail", file)


def task_2():
    file = './music/SchoolBell.mp3'
    try:
        playsound(file)
        play_log("下课", "succees", file)
    except:
        play_log("下课", "fail", file)

def task_3():
    file = './music/classroom.mp3'
    try:
        print("       晚自修结束的时间到了。", "\n")
        playsound(file)
        play_log("教室", "succees", file)
    except:
        play_log("教室", "fail", file)

def task_4():
    file = './music/library.mp3'
    try:
        print("\n", "       夜深了，早点休息吧。", "\n")
        playsound(file)
        print("       好梦~")
        play_log("图书馆", "succees", file)
    except:
        play_log("图书馆", "fail", file)


def play_log(task_name, status, task):
    now_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    with open('./play.log', 'a+', encoding='utf-8') as fp:
        content = now_time + '\t' + task_name + '\t' + status + '\t' + task + '\n'
        fp.write(content)


def display_introduction():
    # 自定义显示界面
    os.system('cls')
    print("\n")
    print('********************************  由 zk B 无聊制作  *******************************')
    print('                                 "借鉴"了 WQT 的代码', '\n')
    print('  【上下课打铃系统】已启动，请勿关闭此窗口.....', '\n')
    print('   若因误操作关闭，请双击【上下课打铃】图标即可重新启动程序。', '\n')
    print('   PS: 播放器使用说明,请查看 /autoplayer/ 目录下的 readme.txt 文档.')
    print('       同一时刻，只保留一个运行窗口，如若运行多次，多余的窗口请手动关闭。', '\n')
    print('       音频质量不好不怪我，只能怪学校发的文件有点问题....', '\n')
    print('**********************************************************************************', '\n')


def main():
    display_introduction()
    while True:
        task_time = time.strftime("%H:%M:%S")
        time.sleep(1)  # 适当控制循环速度(0.5 &lt; 系数 &lt; 1)
        print("\r 当前系统时间: %s" % task_time, end=" ")

###################################################
        if task_time == "08:00:00":  # 任务一  1
            task_1()
        if task_time == "08:45:00":  # 任务二
            task_2()

        if task_time == "08:50:00":  # 任务一  2
            task_1()
        if task_time == "09:35:00":  # 任务二
            task_2()

        if task_time == "09:50:00":  # 任务一  3
            task_1()
        if task_time == "10:35:00":  # 任务二
            task_2()

        if task_time == "10:40:00":  # 任务一  4
            task_1()
        if task_time == "11:25:00":  # 任务二
            task_2()

        if task_time == "11:30:00":  # 任务一  5
            task_1()
        if task_time == "12:15:00":  # 任务二
            task_2()

###################################################
        if task_time == "13:15:00":  # 任务一  6
            task_1()
        if task_time == "14:00:00":  # 任务二
            task_2()

        if task_time == "14:05:00":  # 任务一  7
            task_1()
        if task_time == "14:50:00":  # 任务二
            task_2()

        if task_time == "14:55:00":  # 任务一  8
            task_1()
        if task_time == "15:40:00":  # 任务二
            task_2()

        if task_time == "15:55:00":  # 任务一  9
            task_1()
        if task_time == "16:40:00":  # 任务二
            task_2()

        if task_time == "16:45:00":  # 任务一  10
            task_1()
        if task_time == "17:30:00":  # 任务二
            task_2()

######################################################
        if task_time == "18:30:00":  # 任务一  11
            task_1()
        if task_time == "19:15:00":  # 任务二
            task_2()

        if task_time == "19:20:00":  # 任务一  12
            task_1()
        if task_time == "20:05:00":  # 任务二
            task_2()

        if task_time == "20:10:00":  # 任务一  13
            task_1()
        if task_time == "20:55:00":  # 任务二
            task_2()

######################################################
        if task_time == "22:30:00":  #  梁祝清场
            task_3()
        if task_time == "23:30:00":  #  once in a red moon
            task_4()
####################################################

if __name__ == "__main__":
    main()